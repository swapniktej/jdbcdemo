create table contacts(
 cid number(4) primary key,
 cnm varchar2(34) not null
);

insert into contacts values(101,'Vamsy');