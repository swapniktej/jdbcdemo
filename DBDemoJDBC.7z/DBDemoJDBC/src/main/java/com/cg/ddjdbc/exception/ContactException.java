package com.cg.ddjdbc.exception;

public class ContactException extends Exception {
	public ContactException(String msg) {
		super(msg);
	}
}
