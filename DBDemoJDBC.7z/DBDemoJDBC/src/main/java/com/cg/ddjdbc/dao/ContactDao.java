package com.cg.ddjdbc.dao;

import java.util.List;

import com.cg.ddjdbc.exception.ContactException;
import com.cg.ddjdbc.model.Contact;

public interface ContactDao {
	Contact addContact(Contact contact) throws ContactException;
	Contact updateContact(Contact contact) throws ContactException;
	Contact getContactById(int contactId) throws ContactException;
	List<Contact> getContacts() throws ContactException;
	boolean delContact(int contactId) throws ContactException;
}
