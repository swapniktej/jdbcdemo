package com.cg.ddjdbc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ddjdbc.exception.ContactException;
import com.cg.ddjdbc.model.Contact;
import com.cg.ddjdbc.util.ConnectionProvider;

public class ContactDaoImpl implements ContactDao {

	@Override
	public Contact addContact(Contact contact) throws ContactException {
		try(
			Connection con = ConnectionProvider.getInstance().getConnection();
			PreparedStatement pst = con.prepareStatement(QueryMapper.INS_CONTACT)
				){
			
			pst.setInt(1, contact.getContactId());
			pst.setString(2,contact.getContactName());
			pst.executeUpdate();			
		} catch (SQLException | IOException e) {
			//logger to log e
			throw new ContactException("Sve Operation Failed!");
		}
		return contact;
	}

	@Override
	public Contact updateContact(Contact contact) throws ContactException {
		try(
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.UPD_CONTACTS)
					){
				
				pst.setString(1,contact.getContactName());
				pst.setInt(2, contact.getContactId());
				
				pst.executeUpdate();			
			} catch (SQLException | IOException e) {
				//logger to log e
				throw new ContactException("Sve Operation Failed!");
			}
			return contact;
	}

	@Override
	public Contact getContactById(int contactId) throws ContactException {
		Contact contact =null;
		try(
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.SEL_ALL_CONTACTS_BY_ID)
					){
				
				pst.setInt(1, contactId);
				
				ResultSet rs = 	pst.executeQuery();
				if(rs.next()) {
					contact = new Contact();
					contact.setContactId(rs.getInt("cid"));
					contact.setContactName(rs.getString("cnm"));
				}
			} catch (SQLException | IOException e) {
				//logger to log e
				throw new ContactException("Sve Operation Failed!");
			}
			return contact;		
	}

	@Override
	public List<Contact> getContacts() throws ContactException {
		List<Contact> contacts =new ArrayList<>();
		try(
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.SEL_ALL_CONTACTS)
					){
				
				ResultSet rs = 	pst.executeQuery();
				while(rs.next()) {
					Contact contact = new Contact();
					contact.setContactId(rs.getInt("cid"));
					contact.setContactName(rs.getString("cnm"));
					contacts.add(contact);
				}
			} catch (SQLException | IOException e) {
				//logger to log e
				throw new ContactException("Sve Operation Failed!");
			}
			return contacts;		
	}

	@Override
	public boolean delContact(int contactId) throws ContactException {
		boolean isDeleted=false;
		try(
				Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst = con.prepareStatement(QueryMapper.DEL_CONTACTS)
					){
				
				pst.setInt(1, contactId);				
				isDeleted = pst.executeUpdate()>=1;
				
			} catch (SQLException | IOException e) {
				//logger to log e
				throw new ContactException("Sve Operation Failed!");
			}
			
		return isDeleted;
	}

}
