package com.cg.ddjdbc.dao;

public interface QueryMapper {

	public static final String SEL_ALL_CONTACTS="SELECT cid,cnm FROM contacts";
	public static final String SEL_ALL_CONTACTS_BY_ID="SELECT cid,cnm FROM contacts WHERE cid=?";
	public static final String INS_CONTACT="INSERT INTO contacts(cid,cnm) VALUES(?,?)";
	public static final String UPD_CONTACTS="UPDATE contacts SET cnm=? WHERE cid=?";
	public static final String DEL_CONTACTS="DELETE FROM contacts WHERE cid=?";
}
