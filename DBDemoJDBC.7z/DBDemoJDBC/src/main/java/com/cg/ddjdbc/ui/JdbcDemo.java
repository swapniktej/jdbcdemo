package com.cg.ddjdbc.ui;

import java.util.List;
import java.util.Random;

import com.cg.ddjdbc.dao.ContactDao;
import com.cg.ddjdbc.dao.ContactDaoImpl;
import com.cg.ddjdbc.exception.ContactException;
import com.cg.ddjdbc.model.Contact;

public class JdbcDemo {

	public static void main(String[] args) {
		
		ContactDao dao = new ContactDaoImpl();
		
		try {			
			List<Contact> contacts= dao.getContacts();
			for(Contact contact : contacts) {
				System.out.println(contact.getContactId() +"\t" + contact.getContactName());
			}
		} catch (ContactException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
